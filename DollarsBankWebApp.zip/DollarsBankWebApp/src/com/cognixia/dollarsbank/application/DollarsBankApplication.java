package com.cognixia.dollarsbank.application;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

import com.cognixia.controller.DollarsBankController;
import com.cognixia.model.Customer;
import com.cognixia.model.Transactions;

public class DollarsBankApplication {

	
	public static void main(String[] args) {
		
		List<Customer> customerList = new ArrayList<Customer>();
		List<Transactions> transactions = new ArrayList<Transactions>();
		
		Scanner input = new Scanner(System.in);
		DollarsBankController action = new DollarsBankController();
//		
//		System.out.println("1: Create New Account");
//		System.out.println("2: Login");
//		System.out.println("3. Exit");
//		
//		
//		int choice = input.nextInt();
//
//		switch (choice) {
//		  case 1:
//		    Customer newCustomer = action.createAccount();
//		    customerList.add(newCustomer);
//		    break;
//		  case 2:
//			  
//		    
//			  
//		    break;
//		  case 3:
//		    System.out.println("You chose Exit");
//		    break;
//	}
		
		
//		
		
		
//		Customer c1 = new Customer("Kobe", "Howell", "08/22/2001", "kobe@me.com", "kobe1234", 2000.00);
//		Customer c2 = new Customer("Haley", "Howell", "08/03/1995", "haley@me.com", "haley1234", 3000.00);
//		Customer c3 = new Customer("Prince", "Howell", "03/08/2000", "prince@me.com", "prince1234", 4000.00);
//		Customer c4 = new Customer("Lucy", "Howell", "04/05/1969", "lucy@me.com", "lucy1234", 5000.00);
//		Customer c5 = new Customer("Glenn", "Howell", "01/15/1963", "glenn@me.com", "glenn1234", 6000.00);


//		Customer c2 = action.createAccount();
//		System.out.println(c2.toString());
//		customerList.add(c1);
//		customerList.add(c2);
//		customerList.add(c3);
//		customerList.add(c4);
//		customerList.add(c5);
//
//		

		
		String email = "glenn@me.com";
		String password = "glenn1234";
		
		Customer currentCustomer = action.login(customerList);
		System.out.println(currentCustomer);
		
		action.deposit(120.00, currentCustomer, transactions);
		System.out.println("after first deposit>>>> " + currentCustomer);

		action.deposit(500.00, currentCustomer, transactions);
		
		System.out.println("after second deposit>>>> "+currentCustomer);

		action.withdraw(300.00, currentCustomer, transactions);
		
		System.out.println("after withdraw>>>> "+currentCustomer);

		
		
		System.out.println(currentCustomer);
		for(Transactions t: transactions) {
			System.out.println(t.toString());
		}


		

		
		
			
		

		
		
		
		
		
		
		
		
		
		
		
		
	


		
	
	
	
}
}
