package com.cognixia.repo;

public class AccountRepo {

}
