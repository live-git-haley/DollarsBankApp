package com.cognixia.repo;

public class TransactionRepo {

}
